@tool
extends RefCounted

const PACKAGE_NAME: String = "godot-daedalus_backend"
const BACKEND_BIN_NAME: String = "godot-daedalus-backend"
const MAX_LOG_LINES: int = 80
const MAX_LOG_READ_BYTES: int = 65536
const TCP_PROBE_ATTEMPTS: int = 10
const TCP_PROBE_DELAY_MSEC: int = 20

var backend_url: String
var backend_dev_dir: String
var launch_mode: String
var command_summary: String
var launched_pid: int = -1
var log_file_path: String
var recent_log_lines: Array[String] = []
var last_error: String


func setup(next_backend_url: String, next_backend_dev_dir: String) -> void:
	backend_url = next_backend_url.strip_edges()
	backend_dev_dir = next_backend_dev_dir.strip_edges()
	launch_mode = ""
	command_summary = ""
	launched_pid = -1
	log_file_path = ""
	recent_log_lines.clear()
	last_error = ""


func is_local_backend_url() -> bool:
	var normalized_url: String = backend_url.strip_edges().to_lower()
	if normalized_url.is_empty():
		return true

	return normalized_url == "ws://localhost" \
		or normalized_url.begins_with("ws://localhost:") \
		or normalized_url.begins_with("ws://localhost/") \
		or normalized_url == "ws://127.0.0.1" \
		or normalized_url.begins_with("ws://127.0.0.1:") \
		or normalized_url.begins_with("ws://127.0.0.1/") \
		or normalized_url == "ws://[::1]" \
		or normalized_url.begins_with("ws://[::1]:") \
		or normalized_url.begins_with("ws://[::1]/")


func probe_local_backend_port() -> Dictionary:
	if not is_local_backend_url():
		return {
			"checked": false,
			"occupied": false,
			"host": "",
			"port": 0
		}

	var port_number: int = _parse_backend_url_port()
	if port_number <= 0:
		return {
			"checked": false,
			"occupied": false,
			"host": "127.0.0.1",
			"port": port_number
		}

	var tcp_peer: StreamPeerTCP = StreamPeerTCP.new()
	var connect_error: Error = tcp_peer.connect_to_host("127.0.0.1", port_number)
	if connect_error != OK:
		return {
			"checked": true,
			"occupied": false,
			"host": "127.0.0.1",
			"port": port_number
		}

	for _attempt_index: int in range(TCP_PROBE_ATTEMPTS):
		tcp_peer.poll()
		var tcp_status: StreamPeerTCP.Status = tcp_peer.get_status()
		if tcp_status == StreamPeerTCP.STATUS_CONNECTED:
			tcp_peer.disconnect_from_host()
			return {
				"checked": true,
				"occupied": true,
				"host": "127.0.0.1",
				"port": port_number
			}
		if tcp_status == StreamPeerTCP.STATUS_ERROR:
			return {
				"checked": true,
				"occupied": false,
				"host": "127.0.0.1",
				"port": port_number
			}

		OS.delay_msec(TCP_PROBE_DELAY_MSEC)

	tcp_peer.disconnect_from_host()
	return {
		"checked": true,
		"occupied": false,
		"host": "127.0.0.1",
		"port": port_number
	}


func start_backend() -> Dictionary:
	last_error = ""
	recent_log_lines.clear()
	log_file_path = _prepare_launch_log_file()
	launched_pid = -1

	var command_text: String = _build_launch_command_text()
	if command_text.is_empty():
		return {
			"ok": false,
			"mode": launch_mode,
			"message": last_error,
			"details": build_diagnostic_details()
		}

	var shell_path: String = _get_shell_path()
	var shell_args: PackedStringArray = _get_shell_args(_append_log_redirection(command_text))
	launched_pid = OS.create_process(shell_path, shell_args, false)
	if launched_pid <= 0:
		last_error = "Could not create backend child process."
		return {
			"ok": false,
			"mode": launch_mode,
			"message": last_error,
			"details": build_diagnostic_details()
		}

	return {
		"ok": true,
		"mode": launch_mode,
		"pid": launched_pid,
		"details": build_diagnostic_details()
	}


func poll_logs() -> void:
	_read_launch_log_file()


func get_recent_log_text() -> String:
	return "\n".join(recent_log_lines)


func build_diagnostic_details() -> String:
	poll_logs()
	var lines: Array[String] = []
	lines.append("Backend URL: %s" % backend_url)
	if not launch_mode.is_empty():
		lines.append("Launch mode: %s" % launch_mode)
	if not command_summary.is_empty():
		lines.append("Command: %s" % command_summary)
	if launched_pid > 0:
		lines.append("PID: %d" % launched_pid)
	if not log_file_path.is_empty():
		lines.append("Log file: %s" % log_file_path)
	if not last_error.is_empty():
		lines.append("Error: %s" % last_error)

	var log_text: String = get_recent_log_text()
	if not log_text.is_empty():
		lines.append("")
		lines.append("Recent backend log:")
		lines.append(log_text)

	return "\n".join(lines)


func _parse_backend_url_port() -> int:
	var normalized_url: String = backend_url.strip_edges().to_lower()
	if normalized_url.is_empty():
		return 8080

	var scheme_separator_index: int = normalized_url.find("://")
	var remainder: String = normalized_url
	if scheme_separator_index >= 0:
		remainder = normalized_url.substr(scheme_separator_index + 3)

	var slash_index: int = remainder.find("/")
	if slash_index >= 0:
		remainder = remainder.substr(0, slash_index)

	var port_text: String
	if remainder.begins_with("["):
		var bracket_index: int = remainder.find("]")
		if bracket_index >= 0 and remainder.length() > bracket_index + 2 and remainder.substr(bracket_index + 1, 1) == ":":
			port_text = remainder.substr(bracket_index + 2)
	else:
		var colon_index: int = remainder.rfind(":")
		if colon_index >= 0:
			port_text = remainder.substr(colon_index + 1)

	if port_text.is_valid_int():
		return port_text.to_int()

	if normalized_url.begins_with("wss://"):
		return 443

	return 80


func _build_launch_command_text() -> String:
	if not backend_dev_dir.is_empty():
		var global_dev_dir: String = ProjectSettings.globalize_path(backend_dev_dir)
		if not DirAccess.dir_exists_absolute(global_dev_dir):
			last_error = "Backend development directory does not exist: %s" % global_dev_dir
			launch_mode = "development"
			command_summary = "npm run dev"
			return ""

		launch_mode = "development"
		if OS.get_name() == "Windows":
			command_summary = "cd /d %s && npm run dev" % _quote_command_part(global_dev_dir)
			return command_summary

		command_summary = "cd %s && npm run dev" % _quote_command_part(global_dev_dir)
		return command_summary

	var backend_install_dir: String = _get_backend_install_dir()
	var package_json_path: String = backend_install_dir.path_join("node_modules").path_join(PACKAGE_NAME).path_join("package.json")
	if not FileAccess.file_exists(package_json_path):
		last_error = "Published backend package is not installed. Open Backend Manager and install it first."
		launch_mode = "published"
		command_summary = "npm exec --prefix %s -- %s" % [backend_install_dir, BACKEND_BIN_NAME]
		return ""

	launch_mode = "published"
	command_summary = "npm exec --prefix %s -- %s" % [_quote_command_part(backend_install_dir), BACKEND_BIN_NAME]
	return command_summary


func _get_backend_install_dir() -> String:
	var appdata_path: String = OS.get_environment("APPDATA").strip_edges()
	if appdata_path.is_empty():
		appdata_path = OS.get_user_data_dir()

	return appdata_path.path_join(".godot_daedalus").path_join("backend")


func _get_shell_path() -> String:
	if OS.get_name() == "Windows":
		var shell_path: String = OS.get_environment("COMSPEC").strip_edges()
		if shell_path.is_empty():
			return "cmd.exe"

		return shell_path

	return "/bin/sh"


func _get_shell_args(command_text: String) -> PackedStringArray:
	if OS.get_name() == "Windows":
		return PackedStringArray(["/d", "/s", "/c", command_text])

	return PackedStringArray(["-lc", command_text])


func _prepare_launch_log_file() -> String:
	var user_data_dir: String = OS.get_user_data_dir().strip_edges()
	if user_data_dir.is_empty():
		user_data_dir = _get_backend_install_dir()

	var make_dir_error: Error = DirAccess.make_dir_recursive_absolute(user_data_dir)
	if make_dir_error != OK:
		push_warning("Failed to create Daedalus backend log directory: %s" % error_string(make_dir_error))

	var next_log_file_path: String = user_data_dir.path_join("daedalus_backend_launch.log")
	var log_file: FileAccess = FileAccess.open(next_log_file_path, FileAccess.WRITE)
	if log_file == null:
		push_warning("Failed to create Daedalus backend launch log: %s" % next_log_file_path)
		return ""

	log_file.store_line("Daedalus backend launch log")
	log_file.store_line("Started at: %s" % Time.get_datetime_string_from_system())
	log_file.close()
	return next_log_file_path


func _append_log_redirection(command_text: String) -> String:
	if log_file_path.is_empty():
		return command_text

	var quoted_log_path: String = _quote_command_part(log_file_path)
	if OS.get_name() == "Windows":
		return "%s >> %s 2>&1" % [command_text, quoted_log_path]

	return "%s >> %s 2>&1" % [command_text, quoted_log_path]


func _quote_command_part(value: String) -> String:
	if value.is_empty():
		return "\"\""

	var escaped_value: String = value.replace("\"", "\\\"")
	return "\"%s\"" % escaped_value


func _read_launch_log_file() -> void:
	if log_file_path.is_empty():
		return
	if not FileAccess.file_exists(log_file_path):
		return

	var log_file: FileAccess = FileAccess.open(log_file_path, FileAccess.READ)
	if log_file == null:
		return

	var file_length: int = log_file.get_length()
	if file_length > MAX_LOG_READ_BYTES:
		log_file.seek(file_length - MAX_LOG_READ_BYTES)

	var output_text: String = log_file.get_as_text()
	log_file.close()
	if output_text.is_empty():
		return

	recent_log_lines.clear()
	for line_text: String in output_text.replace("\r\n", "\n").replace("\r", "\n").split("\n", false):
		var trimmed_line: String = line_text.strip_edges()
		if trimmed_line.is_empty():
			continue

		recent_log_lines.append(trimmed_line)

	while recent_log_lines.size() > MAX_LOG_LINES:
		recent_log_lines.remove_at(0)
